# 🛡️ Fraud Detection — End-to-End Analysis Project

An end-to-end fraud-detection pipeline on a synthetic financial transaction dataset
(**230,000 transactions**), covering data cleaning → feature engineering → EDA →
anomaly detection → classification → transaction-risk scoring → dashboards & reports.

> **Resume alignment** — this project demonstrates the exact capabilities listed on the resume:
> - *End-to-end detection pipeline that scored transactions using **anomaly detection** and **feature engineering** in **Python** and **Scikit-learn***
> - *Risk dashboards & **KPI alerts** that flag high-risk transactions in near real time for faster escalation*
> - ***Classification models** and **transaction-risk reports** that surface suspicious activity to stakeholders*

---

## 📊 Key Results

| Metric | Value |
|---|---|
| Transactions scored | 230,000 |
| Confirmed fraud detected | 113 (0.049%) |
| High / Critical risk flagged | 113 |
| Random Forest ROC-AUC | 1.000 |
| Random Forest recall | 1.000 |
| Random Forest precision | 1.000 |
| Isolation Forest ROC-AUC | 0.831 |
| Pipeline runtime | ~17 sec |

> **Note on perfect scores:** the engineered balance-error features are near-deterministic
> signals of fraud *in this synthetic dataset*, so the supervised model separates classes
> almost perfectly. On real-world data, expect lower (but still strong) performance — the
> pipeline, features and thresholds transfer directly.

---

## 🔧 Pipeline Steps

1. **Load & clean** — dedupe, type-cast, null checks.
2. **Feature engineering** — `errorBalanceOrig/Dest`, `origZeroedOut`, `destWasEmpty`,
   `amtToOrigBal`, `isMerchantDest`, `hour`, `day`, `highAmount`, one-hot transaction type.
3. **EDA** — 6 exploratory visualizations.
4. **Anomaly detection** — Isolation Forest (unsupervised risk signal).
5. **Classification** — Random Forest (balanced class weights).
6. **Risk scoring** — composite score `0.7 × fraud_prob + 0.3 × anomaly_score` → Low/Medium/High/Critical tiers.
7. **Export & persist** — scored CSV, Excel workbook, PDF report, interactive dashboard, saved models.

---

## 📁 Deliverables

### Charts (`charts/`)
| File | Description |
|---|---|
| `01_class_distribution.png` | Fraud vs legitimate (log scale) |
| `02_txn_by_type.png` | Transactions & fraud by type |
| `03_fraud_rate_by_type.png` | Fraud rate per channel |
| `04_amount_distribution.png` | Amount distribution fraud vs legit |
| `05_correlation_heatmap.png` | Feature correlation heatmap |
| `06_fraud_over_time.png` | Fraud trend over time |
| `07_confusion_matrix.png` | Random Forest confusion matrix |
| `08_roc_curve.png` | ROC comparison (RF vs Isolation Forest) |
| `09_precision_recall.png` | Precision–Recall curve |
| `10_feature_importance.png` | Top feature importances |
| `11_risk_level_distribution.png` | Transactions by risk tier |

### Data (`data/`)
- `scored_transactions.csv` — every transaction with `fraud_probability`, `anomaly_score`, `risk_score`, `risk_level`.
- `top_high_risk_transactions.csv` — top 500 for the escalation queue.
- `fraud_analysis_report.xlsx` — multi-sheet workbook (KPIs, by-type, risk levels, top high-risk, feature importance).
- `metrics.json` / `dashboard_data.json` — computed metrics.

### Reports (`reports/`)
- `Fraud_Detection_Report.pdf` — full visual report.
- `README.md` — this file.

### Dashboard
- `fraud_detection_dashboard.html` — interactive risk-monitoring dashboard (open in any browser), now including a **cost-based threshold-tuning** panel and **KPI alert tiers**.

### Threshold tuning & cost-based alerting (`data/`)
- `threshold_sweep.csv` — precision/recall/F1/cost/alert-volume across 99 thresholds.
- `alert_rules.json` — recommended cost-minimizing threshold + KPI escalation tiers.
- Charts: `12_cost_curve.png`, `13_metric_vs_threshold.png`, `14_alert_volume.png`.
- **Cost model:** missed fraud (FN) = $500, false alarm review (FP) = $8 → optimal threshold **0.06** (edit assumptions in `03_threshold_tuning.py`).

### Power BI dataset (`powerbi/`)  ⭐ NEW
Star-schema CSVs ready to import into Power BI Desktop:
- `fact_transactions.csv` — fact table (1 row / transaction, with risk scores).
- `dim_transaction_type.csv`, `dim_risk_level.csv`, `dim_date.csv` — dimensions.
- `kpi_measures.csv` — pre-computed KPI card values.
- `DATA_MODEL.md` — relationships, suggested DAX measures, and visual layout.

> **Note:** a true `.pbix` file can only be authored inside Power BI Desktop. These CSVs + `DATA_MODEL.md` let you build the .pbix in ~5 minutes: *Get Data → Text/CSV → import all five → create the documented relationships → paste the DAX measures.*

### Models (`models/`)
- `random_forest_fraud.joblib`, `isolation_forest.joblib`, `scaler.joblib`, `features.json` — production-ready.

---

## ▶️ Reproduce

```bash
pip install pandas numpy scikit-learn matplotlib seaborn openpyxl fpdf2 joblib
python 01_pipeline.py        # cleaning, EDA, models, scoring, exports
python 02_build_report.py    # PDF report
```

**Tech stack:** Python · pandas · NumPy · scikit-learn · matplotlib · seaborn · Chart-style SVG dashboard.
