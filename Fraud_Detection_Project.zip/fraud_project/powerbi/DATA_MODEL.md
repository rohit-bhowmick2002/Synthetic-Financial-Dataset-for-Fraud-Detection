# Power BI Data Model (Star Schema)

Import these CSVs into Power BI Desktop (Get Data > Text/CSV) and create relationships.

## Tables
- **fact_transactions** (grain: 1 row per transaction) — central fact table
- **dim_transaction_type** — descriptive attributes per payment channel
- **dim_risk_level** — risk tiers, SLA, escalation actions
- **dim_date** — step / day / week / hour calendar
- **kpi_measures** — pre-computed KPI card values

## Relationships (Model view)
| From (fact) | To (dim) | Cardinality |
|---|---|---|
| fact_transactions[type_key] | dim_transaction_type[type_key] | Many-to-One |
| fact_transactions[risk_level_key] | dim_risk_level[risk_level_key] | Many-to-One |
| fact_transactions[step] | dim_date[step] | Many-to-One |

## Suggested DAX measures
```
Total Fraud = SUM(fact_transactions[is_fraud_actual])
Fraud Rate % = DIVIDE([Total Fraud], COUNTROWS(fact_transactions)) * 100
High Risk Alerts = CALCULATE(COUNTROWS(fact_transactions), fact_transactions[risk_score] >= 50)
Total Amount = SUM(fact_transactions[amount])
Avg Risk Score = AVERAGE(fact_transactions[risk_score])
Recommended Threshold = 0.06
```

## Suggested visuals
1. KPI cards: Total Fraud, Fraud Rate %, High Risk Alerts, Total Amount
2. Bar: Total Amount & Frauds by dim_transaction_type
3. Donut: transactions by dim_risk_level
4. Line: [Total Fraud] over dim_date[day]
5. Table: top transactions by risk_score with conditional formatting
6. Gauge: model recall vs target
